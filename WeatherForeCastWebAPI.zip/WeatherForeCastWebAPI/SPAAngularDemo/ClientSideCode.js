﻿/// <reference path="wwwroot/lib/angular.js/angular.js" />
var MyApp = angular.module("MyApp", ['ngRoute']);
MyApp.config(['$routeProvider',
    function ($routeProvider) {
        $routeProvider.
            when('/Add', {
                templateUrl: 'Views/Add.html',
                controller: 'AddController'
            }).
            when('/Delete', {
                templateUrl: 'Views/Delete.html',
                controller: 'DeleteController'
            }).
            otherwise({
                redirectTo: '/Home'
            });

    }]);
MyApp.controller("AddController",
    function () {
        $scope.message = "In Add View";
    });
MyApp.controller("DeleteController",
    function () {
        $scope.message = "In Delete View";
    });