﻿/// <reference path="lib/angular.js/angular.js" />
var WeatherService = angular.module('WeatherService', []);
WeatherService.factory('weatherApi', function ($http) {
    var urlBase = "";
    var whetherApi = {};
    whetherApi.getDetails = function () {
        return $http.get(urlBase+'/WeatherforeCast');
    }
}
);