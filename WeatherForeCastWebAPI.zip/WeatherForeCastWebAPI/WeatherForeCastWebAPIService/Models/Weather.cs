﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WeatherForeCastWebAPIService.Models
{
    public class Weather
    {
        public string City { get; set; }
        public int Humidity { get; set; }
        public int Temp { get; set; }

    }
}
