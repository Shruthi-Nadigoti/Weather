﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WeatherForeCastWebAPIService.Models;

namespace WeatherForeCastWebAPIService.Controllers
{
    [Route("api/[controller]")]
    public class WeatherForeCastController : Controller
    {
        [HttpGet("{city}")]
        public Weather Get(string city)
        {
            var weather = new Weather
            {
                City = city,
                Humidity = 12,
                Temp = 35
            };
            return weather;
        } 
       
    }
}