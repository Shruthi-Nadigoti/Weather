﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace WeatherForeCastWebApiConsumer.Helper
{
    public class PublicWeatherForeCastAPI
    {
        public HttpClient Initial()
        { 
             var client = new HttpClient
             {
                BaseAddress = new Uri("http://api.openweathermap.org")
             };
            return client;
        }
    }
}
