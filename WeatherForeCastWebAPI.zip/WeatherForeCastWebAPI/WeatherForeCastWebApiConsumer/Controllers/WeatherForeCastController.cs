﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using WeatherForeCastWebApiConsumer.Helper;
using WeatherForeCastWebApiConsumer.Models;

namespace WeatherForeCastWebApiConsumer.Controllers
{
    public class WeatherForeCastController : Controller
    {
        readonly WeatherForeCastAPI _localWebApi = new WeatherForeCastAPI();
        readonly PublicWeatherForeCastAPI _publicWeatherForeCastapi = new PublicWeatherForeCastAPI();

        public async Task<IActionResult> GetLocalAPI()
        {
            Weather weather = new Weather();
            HttpClient httpClient = _localWebApi.Initial();
            HttpResponseMessage httpResponseMessage = await httpClient.GetAsync("api/WeatherForeCast/x");
            if (httpResponseMessage.IsSuccessStatusCode)
            {
                var result = httpResponseMessage.Content.ReadAsStringAsync().Result;
                weather = JsonConvert.DeserializeObject<Weather>(result);
            }
            return View(weather);
        }
        public async Task<IActionResult> GetPublicAPI()
        {
            //Weather weather = new Weather();
            Object result=null;
            HttpClient httpClient = _publicWeatherForeCastapi.Initial();
            HttpResponseMessage httpResponseMessage = await httpClient.GetAsync("/data/2.5/weather?q={city}&appid=1d8584c898ece5634d52f51238e9051b&units=metric");
            if (httpResponseMessage.IsSuccessStatusCode)
            {
                result = httpResponseMessage.Content.ReadAsStringAsync().Result;
            }
            return View(result);
        }
    }
}