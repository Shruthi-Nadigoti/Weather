﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WeatherForeCastWebApiConsumer.Models
{
    public class WeatherDescription
    {
        public string Main { get; set; }
        public string Description { get; set; }

    }
}
