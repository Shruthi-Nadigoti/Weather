﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WeatherForeCastWebApiConsumer.Models
{
    public class Main
    {
        public string Temp { get; set; }
    }
}
